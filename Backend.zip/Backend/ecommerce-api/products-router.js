const express = require('express');
const router = express.Router();

// Create a new product
router.post('/', async (req, res) => {
  const { data, error } = await supabase
    .from('products')
    .insert([req.body]);
  if (error) {
    console.log(error);
    return res.status(400).send({ message: 'Error creating product', error });
  }
  res.status(201).send({ message: 'Product created successfully', data });
});

// Get all products or filter by category
router.get('/', async (req, res) => {
  const { category } = req.query;
  let query = supabase.from('products').select('*');
  if (category) query = query.eq('category', category);
  const { data, error } = await query;
  if (error) {
    console.log(error);
    return res.status(500).send({ message: 'Error fetching products', error });
  }
  res.send({ message: 'Products fetched successfully', data });
});

// Update a product
router.put('/:id', async (req, res) => {
  const { data, error } = await supabase
    .from('products')
    .update(req.body)
    .match({ id: req.params.id });
  if (error) {
    console.log(error);
    return res.status(400).send({ message: 'Error updating product', error });
  }
  res.send({ message: 'Product updated successfully', data });
});

// Delete a product
router.delete('/:id', async (req, res) => {
  const { data, error } = await supabase
    .from('products')
    .delete()
    .match({ id: req.params.id });
  if (error) {
    console.log(error);
    return res.status(500).send({ message: 'Error deleting product', error });
  }
  res.send({ message: 'Product deleted successfully', data });
});

module.exports = router;
