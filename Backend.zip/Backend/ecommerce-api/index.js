const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { createClient } = require('@supabase/supabase-js');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const supabaseUrl = 'https://unuxdtporgbmublgpwvp.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVudXhkdHBvcmdibXVibGdwd3ZwIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTcxNTg5MTE4MCwiZXhwIjoyMDMxNDY3MTgwfQ.r55ip5T7h9NkqLq-73nujYX_VBZULQHguzl1I8bp068';

global.supabase = createClient(supabaseUrl, supabaseKey);

const productRoutes = require('./products-router');

app.use('/products', productRoutes);

app.get('/', (req, res) => {
  res.send('Hello, your API is running!');
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
